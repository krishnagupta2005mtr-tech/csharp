﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class UpdateDisconnected
    {
        static void Main(string[] args)
        {
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            SqlConnection con = new SqlConnection(cs);

            try
            {
                Console.Write("Enter Student ID to Update: ");
                int id = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter New Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter New Course: ");
                string course = Console.ReadLine();

                Console.Write("Enter New Age: ");
                int age = Convert.ToInt32(Console.ReadLine());

                // Create DataAdapter
                string query = "SELECT * FROM Student WHERE Id = " + id;

                SqlDataAdapter da = new SqlDataAdapter(query, con);

                // Create DataSet
                DataSet ds = new DataSet();

                // Fill DataSet
                da.Fill(ds, "Student");

                if (ds.Tables["Student"].Rows.Count > 0)
                {
                    // Update existing row
                    DataRow row = ds.Tables["Student"].Rows[0];

                    row["Name"] = name;
                    row["Course"] = course;
                    row["Age"] = age;

                    // Generate update command
                    SqlCommandBuilder builder =
                        new SqlCommandBuilder(da);

                    // Update database
                    da.Update(ds, "Student");

                    Console.WriteLine(
                        "\nStudent Record Updated Successfully!");
                }
                else
                {
                    Console.WriteLine("\nStudent ID Not Found!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}
