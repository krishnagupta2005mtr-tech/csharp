﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class CompleteCRUD
    {
        static string cs =
            @"Data Source=.\SQLEXPRESS;
              Initial Catalog=CollegeDB;
              Integrated Security=True;";

        static void Main(string[] args)
        {
            Console.WriteLine("===== ADO.NET CRUD OPERATIONS =====");
            Console.WriteLine("1. Connected Architecture");
            Console.WriteLine("2. Disconnected Architecture");

            Console.Write("Select Architecture: ");
            int architecture =
                Convert.ToInt32(Console.ReadLine());

            if (architecture == 1)
            {
                ConnectedCRUD();
            }
            else if (architecture == 2)
            {
                DisconnectedCRUD();
            }
            else
            {
                Console.WriteLine("Invalid Choice!");
            }

            Console.ReadLine();
        }

        // CONNECTED ARCHITECTURE
        static void ConnectedCRUD()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                Console.WriteLine("\n--- CONNECTED CRUD ---");
                Console.WriteLine("1. Insert");
                Console.WriteLine("2. Display");
                Console.WriteLine("3. Update");
                Console.WriteLine("4. Delete");

                Console.Write("Enter Choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Write("Enter ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter Name: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter Course: ");
                    string course = Console.ReadLine();

                    Console.Write("Enter Age: ");
                    int age = Convert.ToInt32(Console.ReadLine());

                    string query =
                        "INSERT INTO Student VALUES(@Id,@Name,@Course,@Age)";

                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Course", course);
                    cmd.Parameters.AddWithValue("@Age", age);

                    cmd.ExecuteNonQuery();

                    Console.WriteLine("Record Inserted Successfully!");
                }
                else if (choice == 2)
                {
                    string query = "SELECT * FROM Student";

                    SqlCommand cmd = new SqlCommand(query, con);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        Console.WriteLine(
                            dr["Id"] + " " +
                            dr["Name"] + " " +
                            dr["Course"] + " " +
                            dr["Age"]);
                    }

                    dr.Close();
                }
                else if (choice == 3)
                {
                    Console.Write("Enter ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter New Name: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter New Course: ");
                    string course = Console.ReadLine();

                    Console.Write("Enter New Age: ");
                    int age = Convert.ToInt32(Console.ReadLine());

                    string query =
                        "UPDATE Student SET Name=@Name, Course=@Course, Age=@Age WHERE Id=@Id";

                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Course", course);
                    cmd.Parameters.AddWithValue("@Age", age);

                    int result = cmd.ExecuteNonQuery();

                    Console.WriteLine(result > 0
                        ? "Record Updated Successfully!"
                        : "Student Not Found!");
                }
                else if (choice == 4)
                {
                    Console.Write("Enter ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    string query =
                        "DELETE FROM Student WHERE Id=@Id";

                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@Id", id);

                    int result = cmd.ExecuteNonQuery();

                    Console.WriteLine(result > 0
                        ? "Record Deleted Successfully!"
                        : "Student Not Found!");
                }
                else
                {
                    Console.WriteLine("Invalid Choice!");
                }
            }
        }

        // DISCONNECTED ARCHITECTURE
        static void DisconnectedCRUD()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                string query = "SELECT * FROM Student";

                SqlDataAdapter da = new SqlDataAdapter(query, con);

                DataSet ds = new DataSet();

                da.Fill(ds, "Student");

                SqlCommandBuilder builder =
                    new SqlCommandBuilder(da);

                Console.WriteLine("\n--- DISCONNECTED CRUD ---");
                Console.WriteLine("1. Insert");
                Console.WriteLine("2. Display");
                Console.WriteLine("3. Update");
                Console.WriteLine("4. Delete");

                Console.Write("Enter Choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    DataRow row =
                        ds.Tables["Student"].NewRow();

                    Console.Write("Enter ID: ");
                    row["Id"] = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter Name: ");
                    row["Name"] = Console.ReadLine();

                    Console.Write("Enter Course: ");
                    row["Course"] = Console.ReadLine();

                    Console.Write("Enter Age: ");
                    row["Age"] = Convert.ToInt32(Console.ReadLine());

                    ds.Tables["Student"].Rows.Add(row);

                    da.Update(ds, "Student");

                    Console.WriteLine("Record Inserted Successfully!");
                }
                else if (choice == 2)
                {
                    foreach (DataRow row in ds.Tables["Student"].Rows)
                    {
                        Console.WriteLine(
                            row["Id"] + " " +
                            row["Name"] + " " +
                            row["Course"] + " " +
                            row["Age"]);
                    }
                }
                else if (choice == 3)
                {
                    Console.Write("Enter Student ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    DataRow[] rows =
                        ds.Tables["Student"].Select("Id = " + id);

                    if (rows.Length > 0)
                    {
                        Console.Write("Enter New Name: ");
                        rows[0]["Name"] = Console.ReadLine();

                        Console.Write("Enter New Course: ");
                        rows[0]["Course"] = Console.ReadLine();

                        Console.Write("Enter New Age: ");
                        rows[0]["Age"] = Convert.ToInt32(Console.ReadLine());

                        da.Update(ds, "Student");

                        Console.WriteLine("Record Updated Successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Student Not Found!");
                    }
                }
                else if (choice == 4)
                {
                    Console.Write("Enter Student ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    DataRow[] rows =
                        ds.Tables["Student"].Select("Id = " + id);

                    if (rows.Length > 0)
                    {
                        rows[0].Delete();

                        da.Update(ds, "Student");

                        Console.WriteLine("Record Deleted Successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Student Not Found!");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Choice!");
                }
            }
        }
    }
}
