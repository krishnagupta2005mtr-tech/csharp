﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class InsertDisconnected
    {
        static void Main(string[] args)
        {
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            SqlConnection con = new SqlConnection(cs);

            try
            {
                // Take input from user
                Console.Write("Enter Student ID: ");
                int id = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Student Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Course: ");
                string course = Console.ReadLine();

                Console.Write("Enter Age: ");
                int age = Convert.ToInt32(Console.ReadLine());

                // Create DataAdapter
                string query = "SELECT * FROM Student";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                // Create DataSet
                DataSet ds = new DataSet();

                // Fill DataSet
                da.Fill(ds, "Student");

                // Create new row
                DataRow row = ds.Tables["Student"].NewRow();

                row["Id"] = id;
                row["Name"] = name;
                row["Course"] = course;
                row["Age"] = age;

                // Add row to DataSet
                ds.Tables["Student"].Rows.Add(row);

                // Insert command
                SqlCommandBuilder builder =
                    new SqlCommandBuilder(da);

                // Update database
                da.Update(ds, "Student");

                Console.WriteLine(
                    "\nStudent Record Inserted Successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}
