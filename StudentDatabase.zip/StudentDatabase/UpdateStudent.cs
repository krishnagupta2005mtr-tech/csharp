﻿
using System;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class UpdateStudent
    {
        static void Main(string[] args)
        {
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            Console.Write("Enter Student ID to Update: ");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter New Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter New Course: ");
            string course = Console.ReadLine();

            Console.Write("Enter New Age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            SqlConnection con = new SqlConnection(cs);

            try
            {
                con.Open();

                string query = "UPDATE Student SET Name=@Name, Course=@Course, Age=@Age WHERE Id=@Id";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Course", course);
                cmd.Parameters.AddWithValue("@Age", age);

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    Console.WriteLine("Student Record Updated Successfully!");
                }
                else
                {
                    Console.WriteLine("Student ID Not Found!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }

            Console.ReadLine();
        }
    }
}
