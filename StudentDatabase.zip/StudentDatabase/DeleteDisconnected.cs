﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class DeleteDisconnected
    {
        static void Main(string[] args)
        {
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            SqlConnection con = new SqlConnection(cs);

            try
            {
                Console.Write("Enter Student ID to Delete: ");
                int id = Convert.ToInt32(Console.ReadLine());

                // Create DataAdapter
                string query = "SELECT * FROM Student WHERE Id = " + id;

                SqlDataAdapter da = new SqlDataAdapter(query, con);

                // Create DataSet
                DataSet ds = new DataSet();

                // Fill DataSet
                da.Fill(ds, "Student");

                if (ds.Tables["Student"].Rows.Count > 0)
                {
                    // Delete row from DataSet
                    ds.Tables["Student"].Rows[0].Delete();

                    // Generate delete command
                    SqlCommandBuilder builder =
                        new SqlCommandBuilder(da);

                    // Update database
                    da.Update(ds, "Student");

                    Console.WriteLine(
                        "\nStudent Record Deleted Successfully!");
                }
                else
                {
                    Console.WriteLine("\nStudent ID Not Found!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}
