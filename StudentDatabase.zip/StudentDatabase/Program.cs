﻿//using Microsoft.Data.SqlClient;
using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        string cs = @"Data Source=.\SQLEXPRESS;
                      Initial Catalog=CollegeDB;
                      Integrated Security=True;
                      TrustServerCertificate=True;";

        using (SqlConnection con = new SqlConnection(cs))
        {
            try
            {
                con.Open();

                Console.WriteLine("Database Connected Successfully!");

                string query = "SELECT * FROM Student";

                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Console.WriteLine(
                        "ID: " + dr["Id"] +
                        " Name: " + dr["Name"] +
                        " Course: " + dr["Course"] +
                        " Age: " + dr["Age"]
                    );
                }

                dr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        Console.ReadLine();
    }
}