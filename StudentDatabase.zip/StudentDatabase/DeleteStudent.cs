﻿
using System;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class DeleteStudent
    {
        static void Main(string[] args)
        {
            // Connection String
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            // Take Student ID
            Console.Write("Enter Student ID to Delete: ");
            int id = Convert.ToInt32(Console.ReadLine());

            // Create Connection
            SqlConnection con = new SqlConnection(cs);

            try
            {
                // Open Connection
                con.Open();

                Console.WriteLine("Database Connected Successfully!");

                // Delete Query
                string query = "DELETE FROM Student WHERE Id = @Id";

                // Create SqlCommand
                SqlCommand cmd = new SqlCommand(query, con);

                // Add Parameter
                cmd.Parameters.AddWithValue("@Id", id);

                // Execute Command
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    Console.WriteLine("Student Record Deleted Successfully!");
                }
                else
                {
                    Console.WriteLine("Student ID Not Found!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                // Close Connection
                con.Close();
                Console.WriteLine("Database Connection Closed.");
            }

            Console.ReadLine();
        }
    }
}
