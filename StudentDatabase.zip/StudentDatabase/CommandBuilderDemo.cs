﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class CommandBuilderDemo
    {
        static void Main(string[] args)
        {
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            SqlConnection con = new SqlConnection(cs);

            try
            {
                // Create DataAdapter
                string query = "SELECT * FROM Student";

                SqlDataAdapter da =
                    new SqlDataAdapter(query, con);

                // Create DataSet
                DataSet ds = new DataSet();

                // Fill DataSet
                da.Fill(ds, "Student");

                // Create SqlCommandBuilder
                SqlCommandBuilder builder =
                    new SqlCommandBuilder(da);

                Console.WriteLine("1. Insert Student");
                Console.WriteLine("2. Update Student");
                Console.WriteLine("3. Delete Student");

                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    // INSERT
                    DataRow row =
                        ds.Tables["Student"].NewRow();

                    Console.Write("Enter ID: ");
                    row["Id"] = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter Name: ");
                    row["Name"] = Console.ReadLine();

                    Console.Write("Enter Course: ");
                    row["Course"] = Console.ReadLine();

                    Console.Write("Enter Age: ");
                    row["Age"] = Convert.ToInt32(Console.ReadLine());

                    ds.Tables["Student"].Rows.Add(row);

                    da.Update(ds, "Student");

                    Console.WriteLine("Record Inserted Successfully!");
                }
                else if (choice == 2)
                {
                    // UPDATE
                    Console.Write("Enter Student ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    DataRow[] rows =
                        ds.Tables["Student"].Select("Id = " + id);

                    if (rows.Length > 0)
                    {
                        Console.Write("Enter New Name: ");
                        rows[0]["Name"] = Console.ReadLine();

                        Console.Write("Enter New Course: ");
                        rows[0]["Course"] = Console.ReadLine();

                        Console.Write("Enter New Age: ");
                        rows[0]["Age"] = Convert.ToInt32(Console.ReadLine());

                        da.Update(ds, "Student");

                        Console.WriteLine("Record Updated Successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Student ID Not Found!");
                    }
                }
                else if (choice == 3)
                {
                    // DELETE
                    Console.Write("Enter Student ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    DataRow[] rows =
                        ds.Tables["Student"].Select("Id = " + id);

                    if (rows.Length > 0)
                    {
                        rows[0].Delete();

                        da.Update(ds, "Student");

                        Console.WriteLine("Record Deleted Successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Student ID Not Found!");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Choice!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}
