﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace StudentDatabase
{
    class DisplayDataSet
    {
        static void Main(string[] args)
        {
            // Step 1: Connection String
            string cs = @"Data Source=.\SQLEXPRESS;
                          Initial Catalog=CollegeDB;
                          Integrated Security=True;";

            // Step 2: Create Connection
            SqlConnection con = new SqlConnection(cs);

            try
            {
                // Step 3: Create SQL Query
                string query = "SELECT * FROM Student";

                // Step 4: Create SqlDataAdapter
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                // Step 5: Create DataSet
                DataSet ds = new DataSet();

                // Step 6: Fill DataSet
                da.Fill(ds, "Student");

                // Step 7: Display Records
                Console.WriteLine("Student Records:");
                Console.WriteLine("-----------------------------");

                foreach (DataRow row in ds.Tables["Student"].Rows)
                {
                    Console.WriteLine(
                        "ID: " + row["Id"] +
                        " Name: " + row["Name"] +
                        " Course: " + row["Course"] +
                        " Age: " + row["Age"]
                    );
                }

                Console.WriteLine("\nRecords Retrieved Successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}
